package com.desvenx.db;

public class D7XKonstanten {

	// public static final String K_URL =
	// "jdbc:mysql://dsevenxclusteridserverless.cluster-cgfilwl2psrx.us-east-2.rds.amazonaws.com:3306/D7XDB";
	public static final String K_URL = "jdbc:mysql://d7xmysql2.cgfilwl2psrx.us-east-2.rds.amazonaws.com:3306/D7XDB";

	public static final String K_DB_NUTZER = "D7XMASTER";

	public static final String K_DB_PASSWORT = "Sigrid2009$";


	public static final String K_NOT_FOUND = "NOT FOUND";

	public static final String K_SUCESS = "SUCESS";

	public static final String K_NEW_LINE = "\n";

	public static final String K_EINZEL = "E";

	public static final String K_INSGESAMT = "I";

	public static final String K_TRENN_NAME = " ";
	
	public static final String K_TRENN_NAME_KLAMMER_AUF = "(";
	
	public static final String K_TRENN_NAME_KLAMMER_ZU = ")";

	public final static String K_TRENN_USER_HIGHSCORE = " ";

	public final static String K_TRENN_USER = ",";

	public static final int K_LAENGE_PLAYERNAME_IN_DB = 50;

}
